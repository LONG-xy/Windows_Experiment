﻿using System.IO;
using System.IO.Pipes;
using System.Windows;
namespace pipeServer
{
	/// <summary>
	/// MainWindow.xaml 的交互逻辑
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
            ServerTextBox.Text += "Waiting for Client Connection...";

		}
		private void button_Click(object sender, RoutedEventArgs e)
		{
            NamedPipeServerStream pipeServer = new NamedPipeServerStream("TestNamedPipe");
			// Wait for a client to connect
			pipeServer.WaitForConnection();
			StreamReader sr = new StreamReader(pipeServer);
			ServerTextBox.Text = sr.ReadToEnd();

            ServerTextBox.Text += "\r\n---- Messages have been delivered successfully ----";
		}
	}
}
