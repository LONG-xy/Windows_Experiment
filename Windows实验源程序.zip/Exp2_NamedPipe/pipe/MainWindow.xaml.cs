﻿using System.IO;
using System.IO.Pipes;
using System.Windows;

namespace pipe
{
	/// <summary>
	/// MainWindow.xaml 的交互逻辑
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
        }

		private void button_Click(object sender, RoutedEventArgs e)
		{
			NamedPipeClientStream pipeClient = new NamedPipeClientStream("TestNamedPipe");
			ClientPromptTextBox.Text += "Attempting to connect to NamedPipe...";
			pipeClient.Connect();
            ClientPromptTextBox.Text += "\r\nConnected to NamedPipe successfully";

			try
			{
				StreamWriter sw = new StreamWriter(pipeClient);
				sw.AutoFlush = true;
				sw.WriteLine("---- Messages passed by NamedPip ----");
                sw.WriteLine(textBox.Text);
                sw.Close();
                textBox.Text += "\r\nMessages have been delivered successfully";
			}
			catch (IOException error)
			{
				MessageBox.Show(error.ToString());
            }
		}
	}
}
