#pragma once

extern "C" _declspec(dllexport) int __stdcall  testcpp(int a, int b, int c);
extern "C" _declspec(dllexport) int __stdcall  test02(int a, int b);