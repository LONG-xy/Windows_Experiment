﻿using CSharpCreateDLL;
using System.Runtime.InteropServices;
using System.Windows;


namespace CSharpCallDLL
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
	{

		public MainWindow()
		{
			InitializeComponent();

			
		}
		//引入dll
		[DllImport(@"../../../Release/CppCreateDLL.dll", EntryPoint = "testcpp", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
		extern static int testcpp(int a, int b, int c);


		//调用CPP创建的DLL进行加法运算
		private void CppSum(object sender, RoutedEventArgs e)
		{
			var a = this.a.Text;
			var b = this.b.Text;
			var c = this.c.Text;
			int r1 = testcpp(int.Parse(a), int.Parse(b), int.Parse(c));
			this.sum.Text = r1.ToString();
		}

	
		//调用C#创建的DLL进行加法运算
		private void CSSum(object sender, RoutedEventArgs e)
		{
			Class1 CSDLL = new Class1();
			var f = this.f.Text;
			var g = this.g.Text;
			int r3 = CSDLL.Add(int.Parse(f), int.Parse(g));
			this.CSsum.Text = r3.ToString();
		}

		//跳转到使用windows操作系统提供的DLL，实现对注册表的操作
		private void toTest1(object sender, RoutedEventArgs e)
		{
			Test1 test1 = new Test1();
			test1.Show();
			this.Close();
		}
	}
}
