﻿using System.IO;
using System.Text;
namespace FileMerge
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = "";
            string path = @"D:\FileMerge";
            string[] files = Directory.GetFiles(path, "*.txt", SearchOption.TopDirectoryOnly);

            foreach (var file in files)
            {
                using (FileStream fsRead = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.None))
                {
                    using (StreamReader reader = new StreamReader(fsRead, Encoding.Default))
                    {
                        text += reader.ReadToEnd();
                        reader.Close();
                    }
                    fsRead.Close();
                }
            }
            string fnameresult = @"D:\FileMerge\result.txt";
            foreach (var file in files)
            {
                using (FileStream fsWrite = new FileStream(fnameresult, FileMode.Create,
                    FileAccess.Write, FileShare.Write))
                {
                    using (StreamWriter writer = new StreamWriter(fsWrite, Encoding.Default))
                    {
                        writer.Write(text);
                        writer.Close();
                    }
                    fsWrite.Close();
                }
            }
        }
    }
}
