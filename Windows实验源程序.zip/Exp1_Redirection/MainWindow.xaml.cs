﻿using System;
using System.Diagnostics;
using System.Windows;

namespace Windows_Experiment_xy
{
	/// <summary>
	/// MainWindow.xaml 的交互逻辑
	/// </summary>
	public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
		// 调用CMD命令并重定向
		private void RedirectCmd(string command)
		{
			Process process = new Process();
			process.StartInfo.FileName = "cmd.exe";
			// 是否使用外壳程序   
			process.StartInfo.UseShellExecute = false;
			//是否在新窗口中启动该进程的值   
			process.StartInfo.CreateNoWindow = true;
            // 重定向输入输出流											  
			process.StartInfo.RedirectStandardInput = true;
			process.StartInfo.RedirectStandardOutput = true;

			try
			{
				process.Start();
				process.StandardInput.WriteLine(command);
				process.StandardInput.WriteLine("exit");
				//  Console.WriteLine("Start Execution");
				process.OutputDataReceived += (sender, dataReceivedEventArgs) 
                    => AppendResult(dataReceivedEventArgs.Data);
				// 退出时的回调函数，恢复按钮
				process.Exited += (sender, eventArgs)
                    => Getmac.Dispatcher.BeginInvoke(new Action(() => Getmac.IsEnabled = true));
				process.EnableRaisingEvents = true;
				//开始对应用程序的重定向标准输出流执行异步读取操作
				process.BeginOutputReadLine();
			}
			catch (Exception ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
		private void AppendResult(string data)
		{
			Result.Dispatcher.BeginInvoke(new Action(() => Result.AppendText(data + "\n")));
		}

		
		private void GetMac(object sender, RoutedEventArgs e)
        {

            string strCmd = "getmac";
            RedirectCmd(strCmd);
        }
        private void GetMac_OnClick(object sender, RoutedEventArgs e)
        {

            string strCmd = "getmac";
            RedirectCmd(strCmd);
        }

        private void Shutdown_OnClick(object sender, RoutedEventArgs e)
        {
            string strCmd = "shutdown /s /t 3000";
            RedirectCmd(strCmd);
        }
    }
}
