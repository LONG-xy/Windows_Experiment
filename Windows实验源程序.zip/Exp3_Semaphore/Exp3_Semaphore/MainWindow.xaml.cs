﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace Exp3_Semaphore
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        const int BufferSize = 10;
        static  int _productNumber = 0;
        readonly Mutex _mutex;
        readonly Semaphore _fullBuffer;
        readonly Semaphore _emptyBuffer;
        public MainWindow()
        {
            InitializeComponent();
            _mutex = new Mutex();
            _fullBuffer = new Semaphore(0, BufferSize);
            _emptyBuffer = new Semaphore(BufferSize, BufferSize);
        }
   
    private void Btn_Produce(object sender, RoutedEventArgs e)
    { 
        int producerNum = Convert.ToInt16(textProducer.Text);
        int consumerNum = Convert.ToInt16(textConsumer.Text);

        for (int i = 0; i < producerNum; i++)
        {
                Thread producerThread = new Thread(Produce)
                {
                    Name = "Producer" + (i + 1).ToString()
                };
                producerThread.Start();
        }
        for (int i = 0; i < consumerNum; i++) 
        {
                Thread consumerThread = new Thread(Consume)
                {
                    Name = "Consumer" + (i + 1).ToString()
                };
                consumerThread.Start();
        }
    }

    private void Produce()
    {
        while (true)
        {
            _emptyBuffer.WaitOne();
            _mutex.WaitOne();
            
            _productNumber++;  // Put a product in Buffer
            //Debug.WriteLine(Thread.CurrentThread.Name + "   Produced a product，     Current Products: " + _productNumber.ToString() + "\n");
            Dispatcher.BeginInvoke( new UpdateTextDelegate(SetProducerText), Thread.CurrentThread.Name, _productNumber);
            _mutex.ReleaseMutex();
           
            _fullBuffer.Release();
            Thread.Sleep(TimeSpan.FromSeconds(3));
        }
    }

    private void Consume()
    {
       while (true)
       {
           _fullBuffer.WaitOne();
           _mutex.WaitOne();

            _productNumber--;
           //  Debug.WriteLine(Thread.CurrentThread.Name + " Consumed a product，    Current Products: " + _productNumber.ToString() + "\n");
           Dispatcher.BeginInvoke( new UpdateTextDelegate(SetConsumerText), Thread.CurrentThread.Name, _productNumber);
           _mutex.ReleaseMutex();
           
           _emptyBuffer.Release();
           Thread.Sleep(TimeSpan.FromSeconds(4));
       }
    }

    public delegate void UpdateTextDelegate(string name, int number);
    public void SetConsumerText(string name, int number)
    {
        textState.Text += name + " Consumed a product，    Current Products: " + number.ToString() + "\n";
    }
    public void SetProducerText(string name, int number)
    {
        textState.Text += name + "   Produced a product，     Current Products: " + number.ToString() + "\n";
    }
    }
}

